import random

from sklearn import preprocessing
from sklearn.datasets import load_breast_cancer
from sklearn.model_selection import train_test_split

digits = load_breast_cancer()
data = digits.data
# 分割数据，将25%的数据作为测试集，其余作为训练集（你也可以指定其他比例的数据作为训练集）
train_x, test_x, train_y, test_y = train_test_split(data, digits.target, test_size=0.25, random_state=33)
# 采用Z-Score规范化
ss = preprocessing.StandardScaler()
train_x = ss.fit_transform(train_x)
test_x = ss.transform(test_x)

print(len(train_x))
print(len(train_y))
# # 采用Min-Max规范化
# mm = preprocessing.MinMaxScaler()
# train_x = mm.fit_transform(train_x)
# test_x = mm.transform(test_x)

# bc = BaseClassifier(SVM().get_classifier())
# print(bc.train(train_x, train_y, test_x, test_y))

# if __name__ == '__main__':
#     sd = VoteClassifier(train_x, train_y)
#     selT = SelectData()
#     ht = HumanTools()
#     print("data lens : " + str(len(train_x)))
#     select_datas = selT.get_human_datas(test_x, sd)
#     sd.test_accuracy(test_x, test_y)
#
#     new_x = []
#     new_x.extend(train_x)
#     new_y = []
#     new_y.extend(train_y)
#     new_x += select_datas
#     print("data lens : " + str(len(new_x)))
#     new_y += ht.mark_datas(select_datas)
#     sd.re_train(new_x, new_y)
#     select_datas = selT.get_human_datas(test_x,sd)
#     sd.test_accuracy(test_x, test_y)
# 定义一个数组
arr = [
    1, 2, 3, 4, 5, 6, 7, 8, 9, 0
]
# 对age列进行升序排序
arr.insert(0,arr.pop(-1))
# 输出排序结果
print(arr)
