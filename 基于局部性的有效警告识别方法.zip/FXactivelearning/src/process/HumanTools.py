class HumanTools:
    def __init__(self):
        return

    # 标记需要标记的数据策略
    def mark_datas(self, x_datas: list) -> list:
        res = [1 for i in range(len(x_datas))]
        return res
