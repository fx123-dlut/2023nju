import pandas as pd

from src.classifier.MutiClassifier import MutiClassifier
from src.const import Const
from src.const.Const import init_file_map, metrics_start_idx
from src.const.VtypeConst import vtype_map
from src.tool.FileTool import FileTool


class Preprocess:
    def __init__(self, projName=None):
        self.test_data = []
        self.train_data = []
        self.metrics_start = 0
        self.f = FileTool()
        projList = [projName]
        if projName is None:
            projList = Const.project_list
        for i in projList:
            filePath = Const.init_data_dir + i + '/'
            train_data = self.f.get_data_from_file('train_res.csv', filePath)
            test_data = self.f.get_data_from_file('test_res.csv', filePath)
            self.metrics_start = train_data[0].index(metrics_start_idx)
            self.train_data += self.mark_datas(train_data)
            self.test_data += self.mark_datas(test_data)

    def mark_datas(self, datas):
        tmp = []
        for i in datas[1:]:
            i.append(vtype_map[i[init_file_map.get('vtype')]])
            i.append(int(i[init_file_map.get('end_line')]) - int(i[init_file_map.get('start_line')]))
            i.append(int(i[init_file_map.get('priority')]))
            i.append(int(i[init_file_map.get('rank')]))
            i.append(int(i[init_file_map.get('location_count')]))
            i.append(int(i[init_file_map.get('method_count')]))
            i.append(int(i[init_file_map.get('file_count')]))
            if i[init_file_map['mark-vtype']] == 'TP' or i[init_file_map['mark-category']] == 'TP' or \
                    i[init_file_map['mark-all']] == 'TP' or i[init_file_map['resolution']] == 'fixed':
                tmp.append(i + [1])
            elif i[init_file_map['mark-vtype']] == 'FP' or i[init_file_map['mark-category']] == 'FP' or \
                    i[init_file_map['mark-all']] == 'FP':
                tmp.append(i + [0])
        return tmp

    def get_based_marked_info(self, base: int):
        df = pd.DataFrame(self.data)
        df = df.iloc[:, [base, init_file_map['mark-summary']]]
        return df

    def get_metrics_marked_info(self, datas, metrics_start=0, metrics_end=-2):
        x = []
        y = []
        for i in datas:
            now_x = []
            # 添加metrics信息
            for j in i[metrics_start:]:
                now_x.append(float(j))

            x.append(now_x)
            y.append(i[init_file_map['mark-summary']])
        return x, y

    def get_test_datas(self):
        return self.test_data

    def get_train_datas(self):
        return self.train_data

    def get_all_datas(self):
        return self.train_data + self.test_data


if __name__ == '__main__':
    p = Preprocess()
    datas = p.get_train_datas()
    mc = MutiClassifier(datas)
