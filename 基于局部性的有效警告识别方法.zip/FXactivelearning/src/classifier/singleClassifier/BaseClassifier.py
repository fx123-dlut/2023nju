from sklearn.metrics import accuracy_score

from src.tool.MathTool import get_1_prob_form_list


class BaseClassifier:
    def __init__(self, classifier, x_datas, y_datas):
        self.c = classifier
        if len(x_datas) != 0:
            # print(y_datas)
            self.c.fit(x_datas, y_datas)
        return

    def init_classifier(self, x_datas, y_datas):
        self.c.fit(x_datas, y_datas)

    def train(self, x_test):
        predict_y = self.c.predict_proba(x_test)
        return get_1_prob_form_list(predict_y)

    def test(self, test_x=[], test_y=[]):
        predict_y = self.c.predict_proba(test_x)
        predict_y_01 = self.c.predict(test_x)
        predict_y = get_1_prob_form_list(predict_y)
        print(self.c.__class__.__name__ + '准确率: %0.4lf' % accuracy_score(test_y, predict_y_01))
        return predict_y
