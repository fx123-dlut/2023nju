from sklearn.metrics import accuracy_score
from sklearn.svm import SVC

from src.tool.MathTool import get_1_prob_form_list


class SVM:
    def __init__(self):
        return

    def train(self, train_x, train_y, test_x=[], test_y=[]):
        svm = SVC(probability=True)
        svm.fit(train_x, train_y)
        predict_y = svm.predict_proba(test_x)
        predict_y_01 = svm.predict(test_x)
        predict_y = get_1_prob_form_list(predict_y)
        print('SVM准确率: %0.4lf' % accuracy_score(test_y, predict_y_01))
        return predict_y

    # 获取分类器
    def get_classifier(self):
        return SVC(probability=True)

    def train(self, rfc: SVC, test_x=[], test_y=[]):
        predict_y = rfc.predict(test_x)
        print("SVM准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y
