from sklearn.ensemble import GradientBoostingClassifier
from sklearn.metrics import accuracy_score


class GradientBoosting:
    def __init__(self):
        return

    def get_classifier(self):
        return GradientBoostingClassifier(n_estimators=200)

    def train(self, train_x, train_y, test_x=[], test_y=[]):
        gbc = GradientBoostingClassifier(n_estimators=200)
        gbc.fit(train_x, train_y)
        predict_y = gbc.predict(test_x)
        print("Gradient Boosting Decision Tree准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y

    def test(self, gbc: GradientBoostingClassifier, test_x=[], test_y=[]):
        predict_y = gbc.predict(test_x)
        print("Gradient Boosting Decision Tree准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y
