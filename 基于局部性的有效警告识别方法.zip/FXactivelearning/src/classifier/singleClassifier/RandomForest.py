from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score


class RandomForest:
    def __init__(self):
        return

    def get_classifier(self):
        return RandomForestClassifier()

    def train(self, train_x, train_y, test_x=[], test_y=[]):
        rfc = RandomForestClassifier()
        rfc.fit(train_x, train_y)
        predict_y = rfc.predict(test_x)
        print("随机森林准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y

    def test(self, rfc: RandomForestClassifier, test_x=[], test_y=[]):
        predict_y = rfc.predict(test_x)
        print("随机森林准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y