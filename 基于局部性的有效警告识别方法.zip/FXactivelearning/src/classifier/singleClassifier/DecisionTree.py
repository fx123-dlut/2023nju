from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier


class DecisionTree:
    def __init__(self):
        return

    def get_classifier(self):
        return DecisionTreeClassifier(min_samples_leaf=20)

    def train(self, train_x, train_y, test_x=[], test_y=[]):
        dtc = DecisionTreeClassifier()
        dtc.fit(train_x, train_y)
        predict_y = dtc.predict(test_x)
        print("决策树准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y

    def test(self, dtc: DecisionTreeClassifier, test_x=[], test_y=[]):
        predict_y = dtc.predict(test_x)
        print("决策树准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y
