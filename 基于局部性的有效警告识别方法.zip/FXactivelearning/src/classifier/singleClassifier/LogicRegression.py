from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score


class LogicRegression:
    def __init__(self):
        return

    def get_classifier(self):
        return LogisticRegression()

    def train(self, train_x, train_y, test_x=[], test_y=[]):
        lr = LogisticRegression()
        lr.fit(train_x, train_y)
        predict_y = lr.predict(test_x)
        print("罗辑回归准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y

    def test(self, lr: LogisticRegression, test_x=[], test_y=[]):
        predict_y = lr.predict(test_x)
        print("罗辑回归准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y
