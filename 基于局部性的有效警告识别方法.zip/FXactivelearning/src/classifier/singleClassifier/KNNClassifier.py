from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score


class KNNClassifier:
    def __init__(self):
        return

    def get_classifier(self):
        return KNeighborsClassifier()

    def train(self, train_x, train_y, test_x=[], test_y=[]):
        gbc = KNeighborsClassifier(n_estimators=200)
        gbc.fit(train_x, train_y)
        predict_y = gbc.predict(test_x)
        print("Gradient Boosting Decision Tree准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y

    def test(self, gbc: KNeighborsClassifier, test_x=[], test_y=[]):
        predict_y = gbc.predict(test_x)
        print("Gradient Boosting Decision Tree准确率: %.4lf" % accuracy_score(test_y, predict_y))
        return predict_y
