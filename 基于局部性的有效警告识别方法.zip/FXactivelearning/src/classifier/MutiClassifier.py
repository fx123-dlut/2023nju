from itertools import groupby

from src.classifier.VoteClassifier import VoteClassifier
from src.const.Const import init_data_dir, init_file_map, with_metrics_headers, metrics_start_idx
from src.tool.DataTransform import DataTransform
from src.tool.FileTool import FileTool
from imblearn.under_sampling import RandomUnderSampler


class MutiClassifier:
    def __init__(self, datas, based='vtype'):
        self.classifiers = {}
        self.feature_list = {}
        self.dt = DataTransform()
        self.sampler = RandomUnderSampler(random_state=0)
        datas = sorted(datas, key=lambda x: x[init_file_map[based]])
        based_group = groupby(datas, key=lambda x: x[init_file_map[based]])
        for key, group in based_group:
            try:
                vt = VoteClassifier()
                x, y = self.get_metrics_marked_info(list(group), with_metrics_headers.index(metrics_start_idx))
                # 特征提取
                feature_idxs = vt.feature_select(x, y)
                select_x = self.dt.get_select(x, feature_idxs)
                # 欠采样  pip install -U imbalanced-learn
                sample_x, sample_y = self.sampler.fit_resample(select_x, y)
                vt.re_train(sample_x, sample_y)
                self.classifiers[key] = vt
                self.feature_list[key] = feature_idxs
            except ValueError:
                continue
        print(based + ' classifiers init finished')

    def get_metrics_marked_info(self, datas, metrics_start=0, metrics_end=-1):
        x = []
        y = []
        for i in datas:
            now_x = []
            # 添加metrics信息
            for j in i[metrics_start:]:
                now_x.append(float(j))

            x.append(now_x)
            y.append(i[-1])
        return x, y


if __name__ == '__main__':
    ft = FileTool()
    datas = ft.get_data_from_file('test_res.csv', init_data_dir + "commons-collections/")
    mc = MutiClassifier(datas[1:])
