from sklearn.ensemble import ExtraTreesClassifier
from sklearn.feature_selection import SelectFromModel

from src.classifier.singleClassifier.BaseClassifier import BaseClassifier
from src.classifier.singleClassifier.GradientBoosting import GradientBoosting
from src.classifier.singleClassifier.KNNClassifier import KNNClassifier
from src.classifier.singleClassifier.LogicRegression import LogicRegression
from src.classifier.singleClassifier.RandomForest import RandomForest
from src.tool.DataTransform import DataTransform


class VoteClassifier:
    def __init__(self, x_datas: list = [], y_datas: list = []):
        self.dt = DataTransform()
        self.x_datas = x_datas
        self.y_datas = y_datas
        self.models = []
        # self.models.append(BaseClassifier(SVM().get_classifier(), x_datas, y_datas))
        # self.models.append(BaseClassifier(DecisionTree().get_classifier(), x_datas, y_datas))
        # self.models.append(BaseClassifier(KNNClassifier().get_classifier()), x_datas, y_datas)
        self.models.append(BaseClassifier(GradientBoosting().get_classifier(), x_datas, y_datas))
        self.models.append(BaseClassifier(LogicRegression().get_classifier(), x_datas, y_datas))
        self.models.append(BaseClassifier(RandomForest().get_classifier(), x_datas, y_datas))

    # 获取预测结果
    def get_predict_datas(self, x_datas) -> list:
        res = [i.train(x_datas) for i in self.models]
        average = []
        for i in range(len(res[0])):
            score = 0
            for j in res:
                score += j[i]
            average.append(score)
        return res, average

    def get_predice_data_with_feature(self, x_datas, feature_list, shift=0) -> list:
        select_test_x = self.dt.get_select(x_datas, feature_list, shift)
        return self.get_predict_datas(select_test_x)

    # 重新训练模型
    def re_train(self, x_datas, y_datas):
        for model in self.models:
            model.init_classifier(x_datas, y_datas)

    # 测试准确性
    def test_accuracy(self, x_datas, y_datas):
        for model in self.models:
            model.test(x_datas, y_datas)

    def feature_select(self, x_datas, y_datas):
        clf = ExtraTreesClassifier()
        clf = clf.fit(x_datas, y_datas)
        selector = SelectFromModel(clf, prefit=True)
        # 如果为true，则返回被选出的特征下标，如果选择False，则
        # 返回的是一个布尔值组成的数组，该数组只是那些特征被选择
        # feature_list = selector.get_support(True).tolist()
        # feature_list = selector.transform(x_datas)
        feature_list = selector.get_support(True).tolist()
        return feature_list
