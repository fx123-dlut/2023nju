predict_precision = 4

base_dir = "/Users/mayang/PycharmProjects/FXactivelearning/"
init_data_dir = base_dir + 'resource/initdatas/'
res_data_dir = base_dir + 'resource/train_datas/'
turn_data_dir = base_dir + "resource/turn_data/"
font_size = 10

init_file_headers = [
    "categpry", "vtype", "priority", "rank", "project", 'origin commit', 'buggy commit', 'buggy path', 'buggy start',
    "buggy end", "fixer", "fixer path", 'method', 'field', 'resolution', 'lifetime', 'mark-vtype', 'mark-category',
    'mark-all', 'mark TP/FP']

with_metrics_headers = "category,vtype,priority,rank,project,origin commit,buggy commit,buggy path,buggy start," \
                       "buggy end,fixer,fixer path,method,field,resolution,life_time,location_count,method_count," \
                       "file_count,mark-vtype,mark-category," \
                       "mark-all,Kind,Name,File,AvgCyclomatic,AvgCyclomaticModified,AvgCyclomaticStrict," \
                       "AvgEssential,AvgLine,AvgLineBlank,AvgLineCode,AvgLineComment,CountClassBase,CountClassCoupled," \
                       "CountClassCoupledModified,CountClassDerived,CountDeclClass,CountDeclClassMethod," \
                       "CountDeclClassVariable,CountDeclExecutableUnit,CountDeclFile,CountDeclFunction," \
                       "CountDeclInstanceMethod,CountDeclInstanceVariable,CountDeclMethod,CountDeclMethodAll," \
                       "CountDeclMethodDefault,CountDeclMethodPrivate,CountDeclMethodProtected,CountDeclMethodPublic," \
                       "CountInput,CountLine,CountLineBlank,CountLineCode,CountLineCodeDecl,CountLineCodeExe," \
                       "CountLineComment,CountOutput,CountPath,CountPathLog,CountSemicolon,CountStmt,CountStmtDecl," \
                       "CountStmtExe,Cyclomatic,CyclomaticModified,CyclomaticStrict,Essential,Knots,MaxCyclomatic," \
                       "MaxCyclomaticModified,MaxCyclomaticStrict,MaxEssential,MaxEssentialKnots,MaxInheritanceTree," \
                       "MaxNesting,MinEssentialKnots,PercentLackOfCohesion,PercentLackOfCohesionModified," \
                       "RatioCommentToCode,SumCyclomatic,SumCyclomaticModified,SumCyclomaticStrict,SumEssential," \
                       "vtypeNum,codeLine,priority,rank".split(",")

with_metrics_headers1 = "category,vtype,priority,rank,project,origin commit,buggy commit,buggy path,buggy start," \
                       "buggy end,fixer,fixer path,method,field,resolution,life_time,location_count,method_count," \
                       "file_count,mark-vtype,mark-category," \
                       "mark-all,Kind,File,AvgCyclomatic,AvgCyclomaticModified,AvgCyclomaticStrict," \
                       "AvgEssential,AvgLine,AvgLineBlank,AvgLineCode,AvgLineComment,CountClassBase,CountClassCoupled," \
                       "CountClassCoupledModified,CountClassDerived,CountDeclClass,CountDeclClassMethod," \
                       "CountDeclClassVariable,CountDeclExecutableUnit,CountDeclFile,CountDeclFunction," \
                       "CountDeclInstanceMethod,CountDeclInstanceVariable,CountDeclMethod,CountDeclMethodAll," \
                       "CountDeclMethodDefault,CountDeclMethodPrivate,CountDeclMethodProtected,CountDeclMethodPublic," \
                       "CountInput,CountLine,CountLineBlank,CountLineCode,CountLineCodeDecl,CountLineCodeExe," \
                       "CountLineComment,CountOutput,CountPath,CountPathLog,CountSemicolon,CountStmt,CountStmtDecl," \
                       "CountStmtExe,Cyclomatic,CyclomaticModified,CyclomaticStrict,Essential,Knots,MaxCyclomatic," \
                       "MaxCyclomaticModified,MaxCyclomaticStrict,MaxEssential,MaxEssentialKnots,MaxInheritanceTree," \
                       "MaxNesting,MinEssentialKnots,PercentLackOfCohesion,PercentLackOfCohesionModified," \
                       "RatioCommentToCode,SumCyclomatic,SumCyclomaticModified,SumCyclomaticStrict,SumEssential," \
                       "vtypeNum,codeLine,priority,rank".split(",")

all_metrics_headers = with_metrics_headers + ['location_count', 'method_count', 'file_count', 'mark TP/FP',
                                              'average score']

project_list = [
    # 'commons-bcel',
    'commons-codec',
    'commons-collections',
    'commons-configuration',
    'commons-dbcp',
    'commons-net',
    'commons-digester',
    'commons-fileupload',
    'commons-pool',
    'maven-dependency-plugin',   # with_metrics_headers1
]


metrics_start_idx = 'AvgCyclomatic'

init_file_map = {
    'category': 0,
    'vtype': 1,
    'priority': 2,
    'rank': 3,
    'project': 4,
    'start_line': 8,
    'end_line': 9,
    'resolution': 14,
    'lifetime': 15,
    'location_count': 16,  # 同一位置的警告数
    'method_count': 17,  # 同一方法的警告数
    'file_count': 18,  # 同一文件的警告数
    'mark-vtype': 19,
    'mark-category': 20,
    'mark-all': 21,
    'mark-summary': -1
}
