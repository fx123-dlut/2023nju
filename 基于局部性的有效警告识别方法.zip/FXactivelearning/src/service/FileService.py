import os

from src.const.Const import turn_data_dir

from src.tool.FileTool import FileTool


class FileService():
    def __init__(self):
        return

    @staticmethod
    def get_file(projName, turn_nums):
        ft = FileTool()
        filePath = turn_data_dir + projName + "/"
        fileName = "res0-" + str(turn_nums) + ".csv"
        datas = ft.get_data_from_file(fileName, filePath)
        for i in datas:
            i.insert(0, i.pop(-1))
        return datas

    @staticmethod
    def get_last_file(projName, lens):
        ft = FileTool()
        filePath = turn_data_dir + projName + "/"
        files = os.listdir(filePath)
        files.sort(key=lambda x: int(x.split('-')[1].split('.csv')[0]))
        datas = ft.get_data_from_file(files[0], filePath)[0: lens + 1]
        for i in datas:
            i.insert(0, i.pop(-1))
        return datas


if __name__ == '__main__':
    f = FileService()
    print(f.get_last_file("commons-bcel"))
