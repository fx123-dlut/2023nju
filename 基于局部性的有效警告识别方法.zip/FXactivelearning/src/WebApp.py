import os

from flask import Flask, request, render_template
from flask.logging import default_handler

from src.service.FileService import FileService
from src.tool.Logger import LOG

app = Flask(__name__)
app.secret_key = os.urandom(16)
app.logger.removeHandler(default_handler)
app.logger.addHandler(LOG.handlers[0])

fileService = FileService()


@app.route('/turn/search', methods=["GET"])
def getTurnDatas():
    try:
        projName = request.args.get("projName")
        turnNum = request.args.get("turn")
        datas = fileService.get_file(projName, turnNum)
        return datas
    except Exception:
        return "项目或轮次不存在"


@app.route('/turn/searchLast', methods=["GET"])
def getLastTurnDatas():
    try:
        projName = request.args.get("projName")
        nums = int(request.args.get("nums"))
        datas = fileService.get_last_file(projName, nums)
        return datas
    except Exception:
        return "项目或轮次不存在"


if __name__ == '__main__':
    app.run(debug=True, port=8081, threaded=False)
