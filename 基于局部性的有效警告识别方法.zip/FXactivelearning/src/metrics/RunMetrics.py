import re

import numpy as np

from src.const.Const import base_dir, all_metrics_headers
from src.metrics.Metrics import Metrics
from src.tool.FileTool import FileTool


class RunMetrics:
    def __init__(self, projName=None):
        self.metricsTool = Metrics()
        self.ft = FileTool()
        self.projName = projName
        if projName is None:
            return
        self.datas_folder = ['bl1-knn/', 'bl2-EFindBugs/', 'bl3-Adaptively/', 'bl4-mutilLearn/',
                             'bl5-GradientBoosting/', 'bl6-LogicRegression/', 'bl7-RandomForest/', 'bl8-Random/']
        self.datas = []
        for i in self.datas_folder:
            self.datas.append(self.ft.get_data_from_file('res.csv', base_dir + '/resource/' + i + projName + '/'))
        self.datas_folder += [
            'self-method',
            'self-method-no-train-datas',
            'no vtype',
            'no lifetime',
            'no local'
        ]
        self.datas.append(self.ft.get_data_from_file('train-test-process.csv',
                                                     base_dir + '/resource/train_datas/' + projName + '/'))
        self.datas.append(self.ft.get_data_from_file('train-test-process-without-trainSet.csv',
                                                     base_dir + '/resource/train_datas/' + projName + '/'))
        # self.datas.append(self.ft.get_data_from_file('train-test-process.csv',
        #                                              base_dir + "resource/bl9-noVtype/" + projName + '/'))
        self.datas.append(self.ft.get_data_from_file('train-test-process-without-trainSet.csv',
                                                     base_dir + "resource/bl9-noVtype/" + projName + '/'))
        self.datas.append(self.ft.get_data_from_file('train-test-process-without-trainSet.csv',
                                                     base_dir + "resource/bl10-randomActive/" + projName + '/'))
        self.datas.append(self.ft.get_data_from_file('train-test-process-without-trainSet.csv',
                                                     base_dir + "resource/bl11-noLocal/" + projName + '/'))

    def get_metrics_datas(self):
        marked_idx = all_metrics_headers.index('mark TP/FP')
        resolution_idx = all_metrics_headers.index("resolution")
        res = []
        headers = ['method', 'percision@1', 'percision@5', 'percision@10', 'effort', 'F1@10', 'FPavg', 'AUC',
                   'all tp loc']
        for data in self.datas:
            now_res = []
            marked_datas = [1 if i[resolution_idx] == 'fixed' else 0 for i in data[1:]]
            now_res.append(self.datas_folder[self.datas.index(data)])
            now_res.append(self.metricsTool.my_precision_at_k(marked_datas, 1))
            now_res.append(self.metricsTool.my_precision_at_k(marked_datas, 5))
            now_res.append(self.metricsTool.my_precision_at_k(marked_datas, 10))
            now_res.append(self.metricsTool.effort(marked_datas))
            now_res.append(self.metricsTool.f1_at_k1(marked_datas, 20))
            now_res.append(self.metricsTool.FPavg(marked_datas))
            now_res.append(self.metricsTool.auc(marked_datas))
            now_res.append(self.metricsTool.get_all_tp_loc(marked_datas))
            res.append(now_res)
            print("&".join(str(i) for i in now_res[:-1]))
        self.ft.save_to_file(self.projName + '/metrics res', headers, res)
        print(self.projName + "'s summary has finished")
        print()
        print("====================================")
        return res


if __name__ == '__main__':
    r = RunMetrics('commons-collections')
    res = r.get_metrics_datas()
    print(res)
