import numpy as np
from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score


class Metrics:
    def __init__(self):
        return

    def my_precision_at_k(self, true_data: list, k=10):
        k = min(k, len(true_data))
        sum = 0
        for i in range(k):
            if 1 == true_data[i]:
                sum += 1
        return round(sum / k, 4)

    # TP / (TP + FP)
    def precision_at_k(self, true_data: list, predict_data: list, k=10):
        predict_data = predict_data[:k]
        true_data = true_data[:k]
        return precision_score(true_data, predict_data, average='micro')

    # TP / (TP + FN)
    def recall_at_k(self, true_data: list, predict_data: list, k=10):
        predict_data = predict_data[:k]
        true_data = true_data[:k]
        return recall_score(true_data, predict_data, average='micro')

    # 2*P*R/(P+R)，其中P和R分别为 precision 和 recall
    def f1_at_k(self, true_data: list, predict_data: list, k=10):
        predict_data = predict_data[:k]
        true_data = true_data[:k]
        return f1_score(true_data, predict_data, average='micro')

    def f1_at_k1(self, predict_data: list, k=10):
        k = min(k, len(predict_data))
        predict_data = predict_data[:k]
        true_data = [1 for i in range(len(predict_data))]
        return round(f1_score(predict_data, true_data, average='micro'), 4)

    # 统计需要扫描多少数据才能检测所有的正报
    def effort(self, true_data: list):
        res = 0
        for i in range(len(true_data)):
            if true_data[i] == 1:
                res = i + 1
        return round(res / len(true_data), 4)

    def auc(self, true_data: list):
        pred = [1 for i in true_data]
        last_tp = 0
        for i in range(len(true_data)):
            if true_data[i] == 1:
                last_tp = i
        return roc_auc_score(true_data[:last_tp+2], pred[:last_tp+2])

    def get_all_tp_loc(self, true_data: list):
        res = []
        for i in range(len(true_data)):
            if 1 == true_data[i]:
                res.append(i)
        return res

    # 找到每个正报需要扫描的误报数据
    def sr(self, true_data: list):
        res = 0
        now = 0
        for i in range(len(true_data)):
            if true_data[i] == 0:
                now += 1
            else:
                res += now
        return res

    # sr / 正报总数
    def FPavg(self, true_data: list):
        sr = self.sr(true_data)
        Ntp = np.sum(true_data)
        return round(sr / Ntp, 4)

    def performance(self, true_data: list, random_data: list):
        pred = self.FPavg(true_data)
        random = self.FPavg(random_data)
        return random / pred


if __name__ == '__main__':
    m = Metrics()
    true = [1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 1, 1, 1, 0, 0]
    pred = [0, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0, 0, 0, 0]
    # print(m.effort(true, pred))
    # print(m.sr(true, pred))
    # print(m.FPavg(true, pred))
    # print(m.precision_at_k(pred, true))
    # print(m.precision_at_k(pred, true))
    # print(m.recall_at_k(pred, true))
    # print(m.recall_at_k(true, pred))
    # print(m.f1_at_k1(pred))
    print(60 * 8 * 21)
    # print(m.f1_at_k(true, pred))
