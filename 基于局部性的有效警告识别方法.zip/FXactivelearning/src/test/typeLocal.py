from imblearn.under_sampling import RandomUnderSampler

from src.classifier.MutiClassifier import MutiClassifier
from src.classifier.VoteClassifier import VoteClassifier
from src.const.Const import init_file_headers, with_metrics_headers, metrics_start_idx, all_metrics_headers, \
    init_file_map
from src.metrics.Metrics import Metrics
from src.tool.DataTransform import DataTransform
from src.tool.FileTool import FileTool

ft = FileTool()
dt = DataTransform()
vt = VoteClassifier()
mt = Metrics()


def split_datas2label_datas(datas):
    label = []
    for i in datas:
        label.append(i[init_file_headers.index("resolution")])
    return label


def get_datas(fileName, path):
    datas = ft.get_data_from_file(fileName, path)[1:]
    label = split_datas2label_datas(datas)
    return datas, label


def getClassifier(datas):
    sampler = RandomUnderSampler(random_state=0)
    x, y = dt.get_metrics_marked_info(datas, with_metrics_headers.index(metrics_start_idx))
    # x, y = sampler.fit_resample(x, y)
    vt.re_train(x, y)
    return vt


def test(test_datas, classifier):
    x, y = dt.get_metrics_marked_info(test_datas, with_metrics_headers.index(metrics_start_idx))
    now_res, average = classifier.get_predict_datas(x)
    for i in range(len(x)):
        x[i].append(average[i])
    x.sort(key=lambda x: (x[-1], -int(x[init_file_map['lifetime']])), reverse=True)
    true_marked = [1 if i[all_metrics_headers.index("resolution")] == 'fixed' else 0 for i in test_datas]
    return mt.f1_at_k1(true_marked, 2000)


def get_all_datas():
    Atest_datas, Atest_label = get_datas("A.csv", "resource/test/")
    Btest_datas, Btest_label = get_datas("B.csv", "resource/test/")
    Atrain_datas, Atrain_label = get_datas("A.csv", "resource/train/")
    Btrain_datas, Btrain_label = get_datas("B.csv", "resource/train/")
    A = getClassifier(Atrain_datas)
    B = getClassifier(Btrain_datas)
    AB = getClassifier(Atrain_datas + Btrain_datas)
    print(test(Atrain_datas, A))
    print(test(Btest_datas, A))
    print(test(Atest_datas, B))
    print(test(Btrain_datas, B))
    print(test(Atest_datas, AB))
    print(test(Btest_datas, AB))

    # print(Atest_label)


if __name__ == '__main__':
    get_all_datas()
