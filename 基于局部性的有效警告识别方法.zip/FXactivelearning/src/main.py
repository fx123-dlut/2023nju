import warnings

from src.baseLine.RunBaseLine import RunBaseLine
from src.const.Const import project_list
from src.metrics.RunMetrics import RunMetrics
from src.process.SelectData import SelectData
from src.tool.InitTool import InitTool

warnings.filterwarnings('ignore')

if __name__ == '__main__':
    for i in project_list:
        InitTool(i)
        sd = SelectData(i)
        sd.train_and_test(['vtype', 'category', 'project'])
        sd.train_and_test_only_on_trainSet(['vtype', 'category', 'project'])
        # # #
        # 对比实验
        rbl = RunBaseLine(i)
        rbl.get_res(i)
        #
        # 结果测试
        r = RunMetrics(i)
        res = r.get_metrics_datas()

        # 验证属性局部心
        print("")
