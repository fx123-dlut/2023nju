from src.classifier.singleClassifier.BaseClassifier import BaseClassifier
from src.classifier.singleClassifier.GradientBoosting import GradientBoosting
from src.classifier.singleClassifier.LogicRegression import LogicRegression
from src.classifier.singleClassifier.RandomForest import RandomForest
from src.const.Const import all_metrics_headers, base_dir, with_metrics_headers, metrics_start_idx
from src.process.Preprocess import Preprocess
from src.tool.FileTool import FileTool


class BaseLineD:
    """
        不分类不特征选择，直接集成学习
    """

    def __init__(self, x_datas, y_datas):
        self.models = []
        # self.models.append(BaseClassifier(GradientBoosting().get_classifier(), x_datas, y_datas))
        self.models.append(BaseClassifier(LogicRegression().get_classifier(), x_datas, y_datas))
        self.models.append(BaseClassifier(RandomForest().get_classifier(), x_datas, y_datas))

    def get_res(self, y_datas, all_datas, projName=None):
        all_y_datas = [[i for i in j] for j in all_datas]
        predict_datas = [i.train(y_datas) for i in self.models]
        for i in range(len(all_y_datas)):
            sum = 0
            for data in predict_datas:
                sum += data[i]
            all_y_datas[i] += [sum]
        ft = FileTool()
        all_y_datas = sorted(all_y_datas, key=lambda x: x[-1], reverse=True)
        if projName is None:
            ft.save_to_file('res', all_metrics_headers, all_y_datas)
        else:
            ft.save_to_file('res', all_metrics_headers, all_y_datas,
                            base_dir + "resource/bl4-mutilLearn/" + projName + "/")
        return all_y_datas


if __name__ == '__main__':
    p = Preprocess()
    # test_datas = p.get_test_datas()
    # test_df = pd.DataFrame(test_datas)
    # test_df.columns = all_metrics_headers[0:-1]
    # print(test_df['category'])
    train_datas, train_label = \
        p.get_metrics_marked_info(p.get_train_datas(), with_metrics_headers.index(metrics_start_idx))
    test_Datas, test_label = \
        p.get_metrics_marked_info(p.get_test_datas(), with_metrics_headers.index(metrics_start_idx))
    print(train_datas[0])
    print(train_label)
    bla = BaseLineD(train_datas, train_label)
    print(bla.get_res(test_Datas, p.get_test_datas(), 'commons-collections')[0])
