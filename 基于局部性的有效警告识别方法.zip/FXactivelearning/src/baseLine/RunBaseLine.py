import os
import shutil

from src.baseLine.BaseLineNoLocal import BaseLineNoLocal
from src.baseLine.BaseLineA import BaseLineA
from src.baseLine.BaseLineB import BaseLineB
from src.baseLine.BaseLineC import BaseLineC
from src.baseLine.BaseLineD import BaseLineD
from src.baseLine.BaseLineE import BaseLineE
from src.baseLine.BaseLineF import BaseLineF
from src.baseLine.BaseLineG import BaseLineG
from src.baseLine.BaseLineH import BaseLineH
from src.baseLine.BaseLineNovtype import BaseLineNoVtype
from src.baseLine.BaseLineRandomActive import BaseLineRandomActive
from src.const.Const import base_dir, with_metrics_headers, metrics_start_idx
from src.process.Preprocess import Preprocess


class RunBaseLine:
    def __init__(self, projName):
        self.projName = projName
        self.p = Preprocess(projName)
        train_datas, train_label = \
            self.p.get_metrics_marked_info(self.p.get_train_datas(), with_metrics_headers.index(metrics_start_idx))
        self.bl1 = BaseLineA(train_datas, train_label)
        self.bl2 = BaseLineB(self.p.train_data, self.p.test_data)
        self.bl3 = BaseLineC(self.p.train_data, self.p.test_data)
        self.bl4 = BaseLineD(train_datas, train_label)
        self.bl5 = BaseLineE(train_datas, train_label)
        self.bl6 = BaseLineF(train_datas, train_label)
        self.bl7 = BaseLineG(train_datas, train_label)
        self.bl8 = BaseLineH(self.p.test_data)
        self.bl9 = BaseLineNoVtype(self.projName)
        self.bl10 = BaseLineRandomActive(self.projName)
        self.bl11 = BaseLineNoLocal(self.projName)
        if projName is not None:
            self.init_folder(projName)

    def init_folder(self, projName):
        self.init_floder("bl1-knn",projName)
        self.init_floder("bl2-EFindBugs",projName)
        self.init_floder("bl3-Adaptively",projName)
        self.init_floder("bl4-mutilLearn",projName)
        self.init_floder("bl5-GradientBoosting",projName)
        self.init_floder("bl6-LogicRegression",projName)
        self.init_floder("bl7-RandomForest",projName)
        self.init_floder("bl8-Random",projName)
        self.init_floder("bl9-noVtype", projName)
        self.init_floder("bl10-randomActive", projName)
        self.init_floder("bl11-noLocal", projName)

    def init_floder(self, folderName, projName):
        if os.path.exists(base_dir + "resource/" + folderName + "/" + projName + "/"):
            shutil.rmtree(base_dir + "resource/" + folderName + "/" + projName + "/")
        os.makedirs(base_dir + "resource/" + folderName + "/" + projName + "/turn/", exist_ok=True)

    def get_res(self, projName=None):
        test_Datas, test_label = \
            self.p.get_metrics_marked_info(self.p.get_test_datas(), with_metrics_headers.index(metrics_start_idx))
        all_datas = self.p.get_test_datas()
        self.bl1.get_res(test_Datas, all_datas, projName)
        self.bl2.get_res(projName)
        self.bl3.get_res(projName)
        self.bl4.get_res(test_Datas, all_datas, projName)
        self.bl5.get_res(test_Datas, all_datas, projName)
        self.bl6.get_res(test_Datas, all_datas, projName)
        self.bl7.get_res(test_Datas, all_datas, projName)
        self.bl8.get_res(projName)
        self.bl9.train_and_test_only_on_trainSet(['project'])
        self.bl10.train_and_test_only_on_trainSet(['vtype', 'category', 'project'])
        self.bl11.train_and_test_only_on_trainSet(['project'])


if __name__ == '__main__':
    rbl = RunBaseLine('commons-collections')
    rbl.get_res('commons-collections')
