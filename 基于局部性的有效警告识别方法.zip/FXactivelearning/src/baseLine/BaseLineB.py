from typing import List

from collections import defaultdict

import pandas as pd

from src.baseLine.BaseLineModel import BaseLineModel
from src.const.Const import all_metrics_headers, base_dir
from src.process.Preprocess import Preprocess
from src.tool.FileTool import FileTool


class BaseLineB(BaseLineModel):
    """
    实验来源：EFindBugs Effective Error Ranking for FindBugs
    """

    def __init__(self, train_df: list, test_df: list):
        train_df = pd.DataFrame(train_df)
        train_df.columns = all_metrics_headers[0:-1]
        test_df = pd.DataFrame(test_df)
        test_df.columns = all_metrics_headers[0:-1]
        super(BaseLineB, self).__init__("pattern", train_df, test_df)
        self.bc_all_pattern, self.dc_true_pattern, self.kinds_sum, self.kinds_TP_sum = \
            self._calculate_context("category", "vtype")
        self.rank_labels()

    def _calculate_context(self, key_word_kind: str, key_word_pattern: str):
        # pattern分类后的报告总数
        all_pattern_nums = self.train_df.groupby(key_word_pattern).count().iloc[:, 0].to_dict(into=defaultdict(int))
        # pattern分类后的正报数
        true_alarms_num = self.train_df[self.train_df["mark TP/FP"] == 1].groupby(key_word_pattern).count().iloc[:,
                          0].to_dict(into=defaultdict(int))

        # kind分类后的报告总数
        true_kind_nums = self.train_df.groupby(key_word_kind).count().iloc[:, 0].to_dict(into=defaultdict(int))
        # kind分类后的正报数
        error_kind_nums = self.train_df[self.train_df["mark TP/FP"] == 1].groupby(key_word_kind).count(). \
                              iloc[:, 0].to_dict(into=defaultdict(int))

        baseline_context = defaultdict(int)
        baseline_context.update({k: v for k, v in all_pattern_nums.items()})
        deverloper_context = defaultdict(int)
        deverloper_context.update({k: v for k, v in true_alarms_num.items()})
        bug_kinds_size = defaultdict(int)
        bug_kinds_size.update({k: v for k, v in true_kind_nums.items()})
        bug_true_kinds_nums = defaultdict(int)
        bug_true_kinds_nums.update({k: v for k, v in error_kind_nums.items()})
        return baseline_context, deverloper_context, bug_kinds_size, bug_true_kinds_nums

    def _rank_labels(self, data_df: pd.DataFrame) -> List[int]:
        def calculate_dpij(row, _self):
            if _self.bc_all_pattern[row['vtype']] == 0:
                return -1
            return _self.dc_true_pattern[row['vtype']] / _self.bc_all_pattern[row['vtype']]

        def calculate_vpij(row, _self):
            dpij = calculate_dpij(row, _self)
            return (dpij * (1 - dpij)) / _self.kinds_sum[row['vtype'].split("_")[0]]

        def calculate_DKi(row, _self):
            if _self.kinds_sum[row['category']] == 0:
                return -1
            return _self.kinds_TP_sum[row['category']] / _self.kinds_sum[row['category']]

        def get_score(row, _self):
            if calculate_dpij(row, _self) != -1:
                return calculate_dpij(row, _self)
            elif calculate_DKi(row, _self) != -1:
                return calculate_DKi(row, _self)
            else:
                return 0.5

        data_df["rank_score"] = data_df.apply(lambda row: get_score(row, self), axis=1)
        data_df.sort_values("rank_score", inplace=True, ascending=False)
        return data_df

    def get_res(self, projName=None, nums=10):
        ft = FileTool()
        res = []
        i = 0
        while len(self.test_df) > 0:
            nums = min(len(self.test_df), nums)
            print(('=' * 30) + ' ' + str(i) + ' turn: train datas lens : ' + str(len(self.train_df))
                  + "; test datas lens : " + str(len(self.test_df)) + " " + ('=' * 30))
            # 获取对应的数据
            self.bc_all_pattern, self.dc_true_pattern, self.kinds_sum, self.kinds_TP_sum = \
                self._calculate_context("category", "vtype")
            # 排序
            self.rank_labels()
            if projName is not None:
                ft.save_to_file_with_idx('turn', self.test_df.columns.tolist(), self.test_df.values.tolist(),
                                         base_dir + "resource/bl2-EFindBugs/" + projName + "/turn/")
            # 将排序后的数据前十个移动到train_data里面，并删掉对应的数据
            res += self.test_df.values.tolist()[0:nums]
            self.test_df = self.test_df.drop(columns='rank_score')

            self.train_df = pd.DataFrame(
                self.train_df.values.tolist() + self.test_df.values.tolist()[0:nums])
            self.train_df.columns = all_metrics_headers[0:-1] + ['rank_score']
            self.test_df.drop(self.test_df.head(nums).index, inplace=True)
            i += 1
        ft.save_to_file('res', all_metrics_headers[0:-1] + ['rank_score'], res,
                        base_dir + "resource/bl2-EFindBugs/" + projName + "/")
        return res


if __name__ == '__main__':
    p = Preprocess()
    bc = BaseLineB(p.train_data, p.test_data)
    res = bc.get_res('commons-collections')
