from sklearn.neighbors import KNeighborsClassifier

# knn
from src.const.Const import with_metrics_headers, metrics_start_idx, all_metrics_headers, base_dir
from src.process.Preprocess import Preprocess
from src.tool.FileTool import FileTool


class BaseLineA:
    def __init__(self, x_datas, x_label, n=10):
        self.classifier = KNeighborsClassifier(n_neighbors=n)
        self.classifier.fit(x_datas, x_label)

    def get_res(self, y_datas, all_datas, projName=None):
        tmp = [[i for i in j] for j in all_datas]
        predict_datas = self.classifier.predict(y_datas).tolist()
        for i in range(len(tmp)):
            tmp[i] += [predict_datas[i]]
        tmp = sorted(tmp, key=lambda x: x[-1], reverse=True)
        ft = FileTool()
        if projName is None:
            ft.save_to_file('res', all_metrics_headers, tmp)
        else:
            ft.save_to_file('res', all_metrics_headers, tmp, base_dir + "resource/bl1-knn/" + projName + "/")
        return tmp


if __name__ == '__main__':
    p = Preprocess()
    # test_datas = p.get_test_datas()
    # test_df = pd.DataFrame(test_datas)
    # test_df.columns = all_metrics_headers[0:-1]
    # print(test_df['category'])
    train_datas, train_label = \
        p.get_metrics_marked_info(p.get_train_datas(), with_metrics_headers.index(metrics_start_idx))
    test_Datas, test_label = \
        p.get_metrics_marked_info(p.get_test_datas(), with_metrics_headers.index(metrics_start_idx))
    print(train_datas[0])
    print(train_label)
    bla = BaseLineA(train_datas, train_label)
    print(bla.get_res(test_Datas, p.get_test_datas(), 'commons-collections')[0])
