import os
from itertools import groupby

from src.classifier.MutiClassifier import MutiClassifier
from src.classifier.VoteClassifier import VoteClassifier
from src.const.Const import with_metrics_headers, init_file_map, metrics_start_idx, base_dir
from src.process.Preprocess import Preprocess
from src.tool.DataTransform import DataTransform
from src.tool.FileTool import FileTool

# 将警告属性的局部性剥离出去，具体体现在只是用警告的项目名称对数据集进行分类
from src.tool.MathTool import get_groupSum_by_base


class BaseLineNoLocal:
    def __init__(self, projName=None):
        self.projName = projName
        self.p = Preprocess(projName)
        self.dt = DataTransform()
        self.vt = VoteClassifier()
        self.ft = FileTool()

    # 变体1: 直接在测试集上测试
    def train_and_test_only_on_trainSet(self, based_list, turn_nums=10):
        self.p = Preprocess(self.projName)
        tmp = self.p.train_data
        # self.p.test_data = self.p.test_data + self.p.train_data
        i = 1
        self.p.train_data = []
        while get_groupSum_by_base(self.p.train_data,
                                   len(self.p.test_data[0]) + init_file_map.get("mark-summary")) < 2:
            sort_datas = self.p.test_data
            self.p.train_data += sort_datas[:10 * i]
            self.p.test_data = sort_datas[10 * i:]
            i += 1

        fileName = 'train-test-process-without-trainSet'
        if os.path.exists(base_dir + "resource/bl11-noLocal/" + self.projName + '/' + fileName + '.csv'):
            os.remove(base_dir + "resource/bl11-noLocal/" + self.projName + '/' + fileName + '.csv')
        self.ft.add_to_file(self.projName + '/' + fileName,
                            [with_metrics_headers + ['location_count', 'method_count', 'file_count', 'mark TP/FP',
                                                     'average score']], base_dir + "resource/bl11-noLocal/")
        self.ft.add_to_file(self.projName + '/' + fileName, self.p.train_data, base_dir + "resource/bl11-noLocal/")
        self.train_and_test(based_list, turn_nums, 1)
        self.p.train_data = tmp

    # 获取分类器map
    def train_and_test(self, based_list, turn_num=10, type=0):
        i = 1
        while len(self.p.get_test_datas()) > 0:
            print(('=' * 30) + ' ' + str(i) + ' turn: train datas lens : ' + str(len(self.p.train_data))
                  + "; test datas lens : " + str(len(self.p.test_data)) + " "
                  + ('=' * 30))
            classifiers = self.get_classifier(based_list)
            datas, headers = self.test_datas(based_list, classifiers)
            self.ft.save_to_file_with_idx('res' + str(type), headers + ['average score'], datas,
                                          base_dir + "resource/bl11-noLocal/" + self.projName + "/turn/")
            self.next_turn(datas, turn_num, type)
            i += 1

    def next_turn(self, datas, turn_nums, type=0):
        if turn_nums > len(datas):
            turn_nums = len(datas)
        fileName = 'train-test-process'
        if type == 1:
            fileName = 'train-test-process-without-trainSet'
        train_datas = self.p.get_train_datas()
        test_datas = [i[0:-1] for i in datas]
        train_datas += test_datas[0:turn_nums]
        self.p.train_data = train_datas
        self.p.test_data = test_datas[turn_nums:]
        self.ft.add_to_file(self.projName + '/' + fileName, datas[0:turn_nums], base_dir + "resource/bl11-noLocal/")

    def get_classifier(self, based_list):
        classifiers = {}
        for base in based_list:
            classifiers[base] = MutiClassifier(self.p.get_train_datas(), base)
        return classifiers

    # 测试数据，based_list范围由小到大，先排序后分组在进行训练
    def test_datas(self, based_list: list, classifiers: dict):
        res = []
        test_datas = self.p.get_test_datas()
        # 排序
        test_datas = sorted(test_datas, key=lambda x: x[init_file_map.get(based_list[0])])
        # 分组
        # test_group = groupby(test_datas, key=lambda x: (x[init_file_map.get(base)] for base in based_list))
        test_group = groupby(test_datas, key=lambda x: x[init_file_map.get(based_list[0])])
        for key, group in test_group:
            values = list(group)
            for base in based_list:
                if classifiers.get(base) is not None and \
                        classifiers.get(base).classifiers.get(values[0][init_file_map.get(base)]) is not None:
                    print("test used model type and model name : ", base, values[0][init_file_map.get(base)])
                    vt = classifiers.get(base).classifiers.get(values[0][init_file_map.get(base)])
                    feature_lists = classifiers.get(base).feature_list.get(values[0][init_file_map.get(base)])
                    x_values, y = classifiers.get(base).get_metrics_marked_info \
                        (values, with_metrics_headers.index(metrics_start_idx))
                    now_res, average = vt.get_predice_data_with_feature(x_values, feature_lists)
                    for i in range(len(values)):
                        now_line = values[i] + [average[i]]
                        res.append(now_line)
                    break
        res = self.sort_res(res)
        return res, with_metrics_headers + ['mark TP/FP']

    def sort_res(self, datas):
        datas.sort(key=lambda x: (x[-1], -int(x[init_file_map['lifetime']])), reverse=True)
        return datas
