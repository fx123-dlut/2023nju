from collections import defaultdict
from typing import List

import pandas as pd

from src.baseLine.BaseLineModel import BaseLineModel
from src.const.Const import all_metrics_headers, base_dir
from src.process.Preprocess import Preprocess
from src.tool.FileTool import FileTool


class BaseLineC(BaseLineModel):
    """
    Adaptively Ranking Alerts Generated from Automated Static Analysis
    """

    def __init__(self, train_df: list, test_df: list):
        train_df = pd.DataFrame(train_df)
        train_df.columns = all_metrics_headers[0:-1]
        self._get_package(train_df)
        test_df = pd.DataFrame(test_df)
        test_df.columns = all_metrics_headers[0:-1]
        self._get_package(test_df)
        super(BaseLineC, self).__init__("ATA", train_df, test_df)
        self.BC_type, self.DC_type = self._calculate_context("vtype")
        self.BC_sf, self.DC_sf = self._calculate_context("package")
        self.BC_c, self.DC_c = self._calculate_context("File")
        self.BC_m, self.DC_m = self._calculate_context("field")
        self.rank_labels()

    def get_res(self, projName=None, nums=10):
        res = []
        ft = FileTool()
        i = 0
        print(self.train_df.columns.tolist())
        while len(self.test_df) > 0:
            nums = min(len(self.test_df), nums)
            print(('=' * 30) + ' ' + str(i) + ' turn: train datas lens : ' + str(len(self.train_df))
                  + "; test datas lens : " + str(len(self.test_df)) + " " + ('=' * 30))
            # 获取对应的数据
            self.BC_type, self.DC_type = self._calculate_context("vtype")
            self.BC_sf, self.DC_sf = self._calculate_context("package")
            self.BC_c, self.DC_c = self._calculate_context("File")
            self.BC_m, self.DC_m = self._calculate_context("field")
            # 排序
            self.rank_labels()
            if projName is not None:
                ft.save_to_file_with_idx('turn', self.test_df.columns.tolist(), self.test_df.values.tolist(),
                                         base_dir + "resource/bl3-Adaptively/" + projName + "/turn/")
            # 将排序后的数据前十个移动到train_data里面，并删掉对应的数据
            res += self.test_df.values.tolist()[0:nums]
            self.test_df = self.test_df.drop(columns='rank_score')

            self.train_df = pd.DataFrame(
                self.train_df.values.tolist() + self.test_df.values.tolist()[0:nums])
            self.train_df.columns = all_metrics_headers[0:-1] + ['package', 'rank_score']
            self.test_df.drop(self.test_df.head(nums).index, inplace=True)
            i += 1
        ft.save_to_file('res', all_metrics_headers[0:-1] + ['package', 'rank_score'], res,
                        base_dir + "resource/bl3-Adaptively/" + projName + "/")
        return res

    def _get_package(self, data: pd.DataFrame):
        def get_package(row, _self):
            file_name = row["File"]
            try:
                return file_name[:file_name.rindex('\\')]
            except:
                return file_name[:file_name.rindex('.')]

        data['package'] = data.apply(lambda row: get_package(row, self), axis=1)

    def _calculate_context(self, key_word: str):
        # 警告数目
        warnings_num = self.train_df.groupby(key_word).count().iloc[:, 0].to_dict(into=defaultdict(int))
        # 误报数目
        false_alarms_num = self.train_df[self.train_df["mark TP/FP"] == 1].groupby(key_word).count().iloc[:,
                           0].to_dict(into=defaultdict(int))
        # BC
        baseline_context = defaultdict(int)
        baseline_context.update({k: v / len(self.train_df) for k, v in warnings_num.items()})
        # DC
        developer_context = defaultdict(int)
        developer_context.update({k: (2 * false_alarms_num[k] - v) / v for k, v in warnings_num.items()})
        return baseline_context, developer_context

    def _rank_labels(self, data_df: pd.DataFrame) -> List[int]:
        beta_BC, beta_DC = 0.5, 0.5
        gama_sf, gama_c, gama_m = 0.06, 0.65, 0.29

        def calculate_ATA(row, _self):
            return beta_BC * _self.BC_type[row["vtype"]] + beta_DC * _self.DC_type[row["vtype"]]

        def calculate_CL(row, _self):
            return beta_BC * (gama_sf * _self.BC_sf[row["package"]] + gama_c * _self.BC_c[row["File"]] + gama_m *
                              _self.BC_m[row["method"]]) + \
                   beta_DC * (gama_sf * _self.DC_sf[row["package"]] + gama_c * _self.DC_c[row["File"]] + gama_m *
                              _self.DC_m[row["method"]])

        data_df["rank_score"] = data_df.apply(lambda row: (calculate_ATA(row, self) + calculate_CL(row, self)) / 2,
                                              axis=1)
        data_df.sort_values("rank_score", inplace=True, ascending=False)
        return data_df


if __name__ == '__main__':
    p = Preprocess()
    bc = BaseLineC(p.train_data, p.test_data)
    res = bc.get_res('commons-collections')
