import random

from src.const.Const import all_metrics_headers, base_dir
from src.tool.FileTool import FileTool


class BaseLineH:
    """
        random
    """

    def __init__(self, datas):
        self.datas = datas

    def get_res(self, projName=None, turns=100):
        ft = FileTool()
        tmp = [[i for i in j] for j in self.datas]
        for i in range(turns):
            random.shuffle(tmp)
        if projName is None:
            ft.save_to_file('res', all_metrics_headers, tmp)
        else:
            ft.save_to_file('res', all_metrics_headers, tmp,
                            base_dir + "resource/bl8-Random/" + projName + "/")
        return tmp
