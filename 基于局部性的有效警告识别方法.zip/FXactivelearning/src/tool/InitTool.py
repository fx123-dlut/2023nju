import os
import shutil

from src.const.Const import init_data_dir, res_data_dir, turn_data_dir


class InitTool:
    def __init__(self, projName):
        if os.path.exists(res_data_dir + projName):
            shutil.rmtree(res_data_dir + projName)
        if os.path.exists(turn_data_dir + projName):
            shutil.rmtree(turn_data_dir + projName)
        os.makedirs(res_data_dir + projName, exist_ok=True)
        os.makedirs(turn_data_dir + projName, exist_ok=True)
        return
