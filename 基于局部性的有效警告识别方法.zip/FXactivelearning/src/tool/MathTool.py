import pandas as pd

from src.const.Const import predict_precision


def get_list_max_value(datas) -> list:
    res = []
    for i in datas:
        res.append(max(i))
    return res


def get_1_prob_form_list(datas) -> list:
    res = [round(i[1], predict_precision) for i in datas]
    return res


# 获取元素种类
def get_groupSum_by_base(datas: list, based: list) -> int:
    if len(datas) < 1:
        return 0
    df = pd.DataFrame(datas)
    tmp = df[based]
    res = len(tmp.value_counts().index)
    # print(res)
    return res


def get_target_datas(datas: list, base_datas: list, nums: int, door: int = 0.5) -> list:
    res = []
    for i in range(len(datas)):
        cnt = 0
        for j in range(len(base_datas)):
            if base_datas[j][i] > door:
                cnt += 1
            if cnt >= nums:
                res.append(datas[i])
                break
    return res
