import pandas as pd


class DataTransform:
    def __init__(self):
        return

    def df2list(self, df: pd.DataFrame):
        data_list = df.values.tolist()
        x_list = [i[0] for i in data_list]
        y_list = [i[1] for i in data_list]
        return x_list, y_list

    # 根据list提取数组内容
    def get_select(self, datas, select_idx, shift=0):
        select_x = []
        for i in datas:
            now = []
            # print(datas.index(i))
            for j in select_idx:
                now.append(i[j + shift])
            select_x.append(now)
        return select_x

    # 获取警告特征信息
    def get_metrics_marked_info(self, datas, metrics_start=0, metrics_end=-1):
        x = []
        y = []
        for i in datas:
            now_x = []
            # 添加metrics信息
            for j in i[metrics_start:]:
                now_x.append(float(j))
            x.append(now_x)
            y.append(i[-1])
        return x, y
