import csv
import os
import time

from src.const.Const import init_data_dir, res_data_dir, turn_data_dir


class FileTool:
    def __init__(self):
        return

    def get_data_from_file(self, fileName, path=init_data_dir):
        file_dir = path + fileName
        file_datas = []
        with open(file_dir, "r") as f:
            reader = csv.reader(f)
            for i in reader:
                file_datas.append(i)
            f.close()
        return file_datas

    def save_to_file(self, fileName, headers: str, datas, root=res_data_dir):
        with open(root + fileName + ".csv", 'w', newline="") as f:
            writer = csv.writer(f)
            writer.writerow(headers)
            writer.writerows(datas)
            print(root + fileName + ".csv save finished")

    def add_to_file(self, fileName, datas, res_dir=res_data_dir):
        with open(res_dir + fileName + ".csv", 'a', newline="") as f:
            writer = csv.writer(f)
            writer.writerows(datas)
            print(res_dir + fileName + ".csv add finished")

    def save_to_file_with_idx(self, fileName, headers, datas, root=res_data_dir):
        files = os.listdir(root)
        idx = 0
        for i in files:
            if fileName in i:
                idx += 1
        self.save_to_file(fileName + '-' + str(idx), headers, datas, root)

    def save_to_file_with_time(self, fileName, headers, datas):
        files = os.listdir(res_data_dir)
        idx = 0
        for i in files:
            if fileName in i:
                idx += 1
        self.save_to_file(fileName + str(int(time.time())), headers, datas)
