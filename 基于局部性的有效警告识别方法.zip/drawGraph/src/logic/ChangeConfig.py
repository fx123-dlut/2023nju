# from src.const.Const import data_dir
#
#
# class ChangeConfig:
#     def __init__(self):
#         return
#
#     def change_project(self, projName):
#         data_dir = "123"
#
#     def print1(self):
#         print(data_dir)
#
# if __name__ == '__main__':
