import pika

# 用户名和密码
user_info = pika.PlainCredentials('username', 'password')
# 连接服务器上的RabbitMQ服务
connection = pika.BlockingConnection(pika.ConnectionParameters('ip', 5672, '/', user_info))
# 创建一个channel
channel = connection.channel()
# 如果指定的queue不存在，则会创建一个queue，如果已经存在 则不会做其他动作
channel.queue_declare(queue='hello')


# 接受返回的审核结果
def callback(channel, method, prop, body):
    channel.next_turn(body.datas, body.turn_nums)


channel.consume(queue="mark", no_ack=True, on_message_callback=callback)

# 一直处于等待接收消息的状态，如果没收到消息就一直处于阻塞状态，收到消息就调用上面的回调函数
channel.start_consuming()
