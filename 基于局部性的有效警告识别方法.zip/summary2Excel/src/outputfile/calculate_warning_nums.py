# 获取git log map
from src.const.Const import projList, base_dir, git_short_commit_lens
from src.tools.FileTool import FileTool
from src.tools.GitTool import GitClass

filetool = FileTool()


def get_gitlog_map(projname):
    gitTool = GitClass(base_dir + "resource/proj/" + projname + "/")
    map = gitTool.get_commitId_short_map()
    return map


def get_init_datas(projname):
    fixed_datas = filetool.get_data_from_file(
        '/Users/mayang/PycharmProjects/summary2Excel/resource/tmp/' + projname + '/' + projname + '-fixed-alarms.csv',
        '')
    unfixed_datas = filetool.get_data_from_file(
        '/Users/mayang/PycharmProjects/summary2Excel/resource/tmp/' + projname + '/unfixed-' + projname + '.csv', '')
    return fixed_datas + unfixed_datas


def run():
    for projname in projList:
        map = get_gitlog_map(projname)
        datas = get_init_datas(projname)
        sum = 0
        for i in datas:
            start = map.get(i[5][0:git_short_commit_lens])
            end = map.get(i[10][0:git_short_commit_lens])
            if end is None:
                end = 0
            # print(start, i[5])
            sum += (start - end)
        print(projname, sum)
        # return


if __name__ == '__main__':
    run()
