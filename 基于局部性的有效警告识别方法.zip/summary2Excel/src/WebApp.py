import os
import time

import requests
from flask import Flask, request, render_template
from flask.logging import default_handler

from src.const.Const import tmp_base
from src.const.WebConst import ALUrl
from src.service import ProjectService
from src.tools import FileTool
from src.tools.Logger import LOG
from src.tools.RequestTool import request_get

app = Flask(__name__)
app.secret_key = os.urandom(16)
app.logger.removeHandler(default_handler)
app.logger.addHandler(LOG.handlers[0])

p = ProjectService.ProjectService()


@app.route('/project/download', methods=["GET"])
def downloadProject():
    projUrl = request.args.get("projUrl")
    if p.downLoadProject(projUrl):
        return '{"msg":false}'
    return render_template("analyse.html")
    # return '<h1>success<h1>'


@app.route('/project/analyse', methods=["GET"])
def analyseProject():
    projName = request.args.get("projName")
    p.analyseProject(projName)
    return '<h1>%s<h1>' % projName


@app.route('/project/metrics', methods=["POST"])
def metricsProject():
    projName = request.args.get("projName")
    # p.metricsProject(projName)
    time.sleep(1)
    return '<h1>%s<h1>' % projName


@app.route('/project/summary', methods=["GET"])
def summaryProject():
    p.summaryProject()
    return '<h1>success<h1>'


@app.route('/upload/analyse', methods=["POST"])
def upload_file():
    info = ""
    try:
        tpfile = request.files.get("tpfile")
        fpfile = request.files.get("fpfile")
        projName = request.form.get("projName")
        folder_path = tmp_base + projName + "/"
        FileTool.rebuild_dir(folder_path, True)
        tpfile.save(folder_path + tpfile.name + ".csv")
        fpfile.save(folder_path + fpfile.name + ".csv")
        info = "项目下载成功"
    except Exception:
        print(Exception.args)
        info = "下载文件失败"
    try:
        p.analyseProject(projName)
        info = "项目分析成功"
    except Exception:
        info = "项目错误"
    return render_template("metricsCombine.html")
    # return '<h1>%s<h1>' % info


@app.route('/upload/metrics', methods=["POST"], endpoint="upload/metrics")
def upload_file():
    try:
        metricsFiles = request.files.get("metrics")
        projName = request.form.get("projName")
        # p.metricsProcess(projName, metricsFiles)
        # tpfile.save(folder_path + .name + ".csv")
        info = "项目下载成功"
    except Exception:
        print(Exception.args)
        info = "下载文件失败"
    return '<h1>%s<h1>' % info


@app.route("/file", methods=['GET'], endpoint="file")
def get_file_data():
    headers = []
    datas = []
    info = ""
    try:
        if request.method == "GET":
            projName = request.args.get("projName")
            headers, datas = p.getProjDatas(projName)
            info = "项目获取成功"
        return render_template("dataPageDetail.html", title="漏洞详情", nav_list=datas, headers=headers, info=info)
    except Exception:
        return '<h1>%s<h1>' % "项目不存在"


@app.route('/turn/search', methods=["GET"])
def getTurnDatas():
    try:
        projName = request.args.get("projName")
        turnNum = request.args.get("turn")
        post_url = ALUrl + "turn/search"
        bodys = {"projName": projName, "turn": turnNum}
        datas = request_get(post_url, bodys)
        headers = datas[0]
        datas = datas[1:]
        info = projName + " " + turnNum + " has read finished"
        return render_template("dataMarkPageDetail.html", title="警告历史信息", nav_list=datas, headers=headers, info=info)
    except Exception:
        return '<h1>%s<h1>' % "项目或轮次不存在"


@app.route('/turn/searchLast', methods=["GET"])
def getLastTurnDatas():
    try:
        projName = request.args.get("projName")
        nums = 5
        post_url = ALUrl + "turn/searchLast"
        bodys = {"projName": projName, "nums": nums}
        datas = request_get(post_url, bodys)
        headers = datas[0]
        datas = datas[1:]
        info = projName + " has read finished"
        return render_template("dataMarkListDetail.html", title="警告审核列表", nav_list=datas, headers=headers, info=info)
    except Exception:
        return '<h1>%s<h1>' % "项目或轮次不存在"


if __name__ == '__main__':
    app.run(debug=True, port=8080, threaded=False)
